package jdbc;

public class TesteConexao02Main {

	public static void main(String[] args) {
		TesteConexao02.getConnection();
	}
}
